<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *"); // permite acesso do navegador
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

$data = json_decode(file_get_contents("php://input"), true);
$file = "avaliacoes.json";

if (!$data || empty($data["comentario"]) || empty($data["estrelas"])) {
    echo json_encode(["status" => "erro", "mensagem" => "Dados inválidos."]);
    exit;
}

// Carrega as avaliações existentes
$avaliacoes = file_exists($file) ? json_decode(file_get_contents($file), true) : [];

// Adiciona nova avaliação no início da lista
$data["data"] = date("Y-m-d H:i");
$avaliacoes = array_merge([$data], $avaliacoes);

// Salva o JSON atualizado
file_put_contents($file, json_encode($avaliacoes, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

echo json_encode(["status" => "ok"]);
?>
