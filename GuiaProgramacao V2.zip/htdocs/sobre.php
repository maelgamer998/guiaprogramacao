<?php
include_once __DIR__ . '/contador_guias.php';
$totalGuides = $resultado['total'];
$guides = $resultado['arquivos'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Sobre — Guia de Programação</title>
  <link rel="icon" type="image/png" href="assets/svg/route.svg">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <meta name="description" content="Sobre o Guia de Programação — missão, equipe e comunidade.">
  <style>
    /* ===========================
       Reset / Base (adaptado do index)
       =========================== */
    *,*::before,*::after{box-sizing:border-box}
    html,body{height:100%;margin:0;padding:0}
    body{
      font-family:'Poppins', arial, sans-serif;
      color:#e0e0e0;
      background:radial-gradient(circle at 20% 30%, #0f172a, #020617);
      overflow-x:hidden;
      position:relative;
      min-height:100vh;
      display:flex;
      flex-direction:column;
    }
    .background-code{
      position:fixed;inset:0;
      background:repeating-linear-gradient(0deg, rgba(0,255,150,0.05) 0px, rgba(0,255,150,0.05) 1px, transparent 2px, transparent 4px);
      animation:flicker 3s infinite alternate;
      z-index:-1;
    }
    @keyframes flicker{0%{opacity:.4;transform:translateY(0);}50%{opacity:.6;transform:translateY(-2px);}100%{opacity:.5;transform:translateY(2px);}}

    main{flex:1;width:100%}
    .wrap{max-width:1100px;margin:80px auto;padding:24px;width:100%;}

    /* ============= HEADER (igual ao index) ============= */
    .top-header {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      background: rgba(15, 23, 42, 0.95);
      backdrop-filter: blur(20px) saturate(180%);
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      z-index: 999;
      padding: 12px 0;
      box-shadow: 0 4px 30px rgba(0, 0, 0, 0.4);
      transition: all 0.3s ease;
    }
    .top-header .container { max-width:1100px;margin:0 auto;padding:0 24px;display:flex;justify-content:space-between;align-items:center; }
    .top-header .logo { display:flex; align-items:center; gap:12px; }
    .top-header .logo a { text-decoration:none;background:linear-gradient(90deg,#60a5fa,#a78bfa);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-weight:700;font-size:18px; }
    .top-header .logo-icon { width:40px;height:40px;background:linear-gradient(135deg,#6366f1,#a855f7);border-radius:6px;display:flex;align-items:center;justify-content:center;padding:4px; }
    .top-header .logo-icon img{width:30px;height:30px;filter:brightness(0) invert(1);display:block;}
    .top-header .menu { display:flex; gap:8px; align-items:center; }
/* Botões já existentes */
.btn {
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding:10px 16px;
  border-radius:8px;
  border:none;
  cursor:pointer;
  background:rgba(99,102,241,0.12);
  color:#c7d2fe;
  font-weight:600;
  transition:all .25s ease, transform .2s ease;
  text-decoration:none;
  position:relative;
  overflow:hidden;
}

/* Botão primário */
.btn.primary {
  background:linear-gradient(135deg,#6366f1,#a855f7);
  color:#fff;
  box-shadow:0 6px 20px rgba(99,102,241,0.2);
}

/* Hover geral */
.btn:hover {
  transform: translateY(-3px) scale(1.03);
  background: rgba(99,102,241,0.2);
}

/* Hover botão primário */
.btn.primary:hover {
  transform: translateY(-3px) scale(1.05);
  box-shadow:0 10px 25px rgba(99,102,241,0.35);
  background: linear-gradient(135deg,#7f7cfb,#c278f2);
}

/* Hover ícones nos botões */
.btn i {
  transition: transform .3s ease;
}

.btn:hover i {
  transform: rotate(-10deg) scale(1.1);
}

/* Ripple-like effect ao clicar (opcional) */
.btn:active::after {
  content:'';
  position:absolute;
  top:50%; left:50%;
  width:100%; height:100%;
  background:rgba(255,255,255,0.1);
  border-radius:50%;
  transform:translate(-50%,-50%) scale(0);
  animation: ripple 0.4s ease-out forwards;
}

@keyframes ripple {
  to { transform:translate(-50%,-50%) scale(2); opacity:0; }
}


    /* ============= HERO ============= */
    .hero{
      background: linear-gradient(135deg, rgba(20,20,35,0.95), rgba(30,30,50,0.9));
      border-radius: 20px;
      box-shadow: 0 20px 40px rgba(0,0,0,0.4);
      padding: 36px;
      display:flex;gap:24px;align-items:center;position:relative;overflow:hidden;border:1px solid rgba(255,255,255,0.06);
    }
    .hero .cover{ width:110px;height:110px;border-radius:14px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg, rgba(99,102,241,0.18), rgba(168,85,247,0.12));border:1px solid rgba(255,255,255,0.06) }
    .hero h1{margin:0;font-size:30px;background:linear-gradient(90deg,#60a5fa,#a78bfa,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
    .hero p.lead{color:#d1d5db;margin:6px 0 12px 0;max-width:640px;line-height:1.6}

    /* ============= GRID SECTIONS ============= */
    .grid-sections { display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:18px; margin-top:18px; }

    .card { background:rgba(20,20,35,0.9); padding:18px; border-radius:12px; border:1px solid rgba(255,255,255,0.04); box-shadow:0 8px 24px rgba(0,0,0,0.35); transition:transform .25s ease; }
    .card h3{margin:0 0 8px 0;font-size:18px;background:linear-gradient(90deg,#e0e0e0,#a78bfa);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
    .card p{color:#a1a1aa;font-size:14px;line-height:1.5}

    /* ============= GUIAS GRID ============= */
    .grid-guias { display:grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap:16px; margin-top:12px; }
    .guia-card { display:flex; flex-direction:column; align-items:center; text-decoration:none; padding:16px 10px; border-radius:12px; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.04); transition: all .25s ease; }
    .guia-card:hover { transform:translateY(-6px); background:rgba(99,102,241,0.08); border-color:rgba(99,102,241,0.2); box-shadow:0 12px 30px rgba(99,102,241,0.08); }
    .guia-icon{ width:56px; height:56px; display:flex; align-items:center; justify-content:center; margin-bottom:10px; border-radius:10px; background: linear-gradient(135deg, rgba(99,102,241,0.06), rgba(168,85,247,0.04)); }
    .guia-icon img{ width:46px; height:46px; object-fit:contain; filter: drop-shadow(0 6px 10px rgba(0,0,0,0.45)); }
    .guia-nome{ font-weight:700; color:#e0e0e0; text-align:center; font-size:14px; text-transform:capitalize; }

    /* remove underline globally for these link styles */
    a { text-decoration: none; color: inherit; outline: none; }
    .list-guides a:hover, .guia-card:hover { text-decoration: none; }

    /* Floating guide counter */
    .guide-counter-fixed{ position:fixed; bottom:22px; right:22px; background:rgba(20,20,35,0.95); padding:12px 16px; border-radius:12px; border:1px solid rgba(99,102,241,0.25); display:flex; gap:10px; align-items:center; z-index:999; box-shadow:0 10px 30px rgba(0,0,0,0.4); opacity:0; transform:translateY(20px); transition:all .35s ease; }
    .guide-counter-fixed.show{ opacity:1; transform:translateY(0); }
    .guide-counter-fixed .count{ background:linear-gradient(135deg,#6366f1,#a855f7); color:#fff; padding:4px 8px; border-radius:8px; font-weight:800; }

    /* Modal (stats) */
    .modal-overlay{ position:fixed; inset:0; background: rgba(0,0,0,0.8); z-index:1200; display:none; align-items:center; justify-content:center; padding:20px; }
    .modal{ background: linear-gradient(135deg,#1e1e32,#0f172a); border-radius:14px; padding:18px; max-width:900px; width:100%; border:2px solid rgba(99,102,241,0.14); box-shadow:0 25px 60px rgba(0,0,0,0.6); }
    .modal h2{ margin:0 0 6px 0; color:#e6e9ff; }
    .modal .small{ color:#9aa3b9; font-size:13px; margin-bottom:12px; }
    .modal .stats-list { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:12px; margin-top:12px; }
    .stat-item { background:rgba(255,255,255,0.02); padding:10px; border-radius:10px; display:flex; gap:10px; align-items:center; border:1px solid rgba(255,255,255,0.03); }
    .stat-item .icon { width:44px; height:44px; display:flex; align-items:center; justify-content:center; border-radius:8px; background:linear-gradient(135deg, rgba(99,102,241,0.08), rgba(168,85,247,0.06)); }
    .stat-item .text { color:#dfe6ff; font-weight:700; }

    /* small animations */
    .float-up { animation: floatUp 3s ease-in-out infinite; }
    @keyframes floatUp { 0%{transform:translateY(0)}50%{transform:translateY(-6px)}100%{transform:translateY(0)} }
    .fade-in { animation: fadeIn 0.6s ease both; }
    @keyframes fadeIn { from { opacity:0; transform: translateY(12px) } to { opacity:1; transform: translateY(0) } }

    /* responsive tweaks */
    @media (max-width:768px) {
      .hero{flex-direction:column;text-align:center}
      .wrap{margin:110px auto 40px}
    }
/* Notificação toast */
.copy-toast {
  position: fixed;
  bottom: 30px;
  right: 30px;
  background: linear-gradient(135deg, #6366f1, #a855f7);
  color: #fff;
  padding: 12px 18px;
  border-radius: 10px;
  box-shadow: 0 8px 25px rgba(0,0,0,0.4);
  font-weight: 600;
  font-size: 15px;
  display: flex;
  align-items: center;
  gap: 10px;
  opacity: 0;
  transform: translateY(20px);
  pointer-events: none;
  transition: all 0.4s ease;
  z-index: 1500;
}
.copy-toast.show {
  opacity: 1;
  transform: translateY(0);
  pointer-events: auto;
}
.copy-toast i {
  font-size: 17px;
}

  </style>
</head>
<body>

<!-- Notificação de cópia -->
<div id="copyNotification" class="copy-toast">
  <i class="fa-solid fa-check"></i>
  <span>Convite copiado!</span>
</div>

  <div class="background-code"></div>

  <!-- HEADER -->
  <header class="top-header">
    <div class="container">
      <div class="logo">
        <div class="logo-icon"><img src="assets/svg/route.svg" alt="logo"></div>
        <a href="index.html">Guia de Programação</a>
      </div>
      <div class="menu">
        <a class="btn" href="index.html"><i class="fa-solid fa-house"></i> Início</a>
        <button class="btn" onclick="openStats();"><i class="fa-solid fa-chart-simple"></i> Estatísticas</button>
        <a class="btn primary" href="https://discord.gg/kYvgJRuxTe" target="_blank" rel="noopener"><i class="fa-brands fa-discord"></i> Entrar no Discord</a>
      </div>
    </div>
  </header>

  <main>
    <div class="wrap">

      <!-- HERO -->
      <section class="hero fade-in" style="margin-top:10px">
        <div class="cover">
          <img src="assets/img/logo.png" alt="logo" style="width:72%;height:72%;object-fit:contain">
        </div>
        <div style="flex:1">
          <h1>Sobre o Guia de Programação</h1>
          <p class="lead">Portal colaborativo com guias práticos e objetivos — do HTML ao DevOps. Conteúdo feito para aprender com exemplos aplicáveis e rápidos.</p>
          <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap">
            <span class="btn">Tutoriais</span>
            <span class="btn">Referências</span>
            <span class="btn">Exemplos</span>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:12px">
          <button class="btn" onclick="document.getElementById('quem-somos').scrollIntoView({behavior:'smooth'})"><i class="fa-solid fa-users"></i> Quem Somos</button>
          <a class="btn primary" href="https://discord.gg/kYvgJRuxTe" target="_blank" rel="noopener"><i class="fa-brands fa-discord"></i> Entrar na Comunidade</a>
        </div>
      </section>

      <!-- SEÇÕES INFORMATIVAS -->
      <div class="grid-sections" style="margin-top:18px">
        <div class="card fade-in">
          <h3 id="quem-somos">Quem somos</h3>
          <p>Somos uma comunidade de desenvolvedores, instrutores e entusiastas. Nosso objetivo é explicar conceitos com clareza, exemplos práticos e códigos que você pode testar imediatamente.</p>
        </div>

        <div class="card fade-in">
          <h3>Objetivo</h3>
          <p>Produzir guias completos e objetivos que ajudem no aprendizado prático e na resolução de problemas reais.</p>
        </div>

        <div class="card fade-in">
          <h3>Para que é usado</h3>
          <p>Estudo pessoal, apoio em aulas, material de referência para tutores e consultas rápidas no dia a dia do desenvolvimento.</p>
        </div>

        <div class="card fade-in">
          <h3>Como contribuir</h3>
          <p>Envie sugestões no Discord ou contribua com arquivos (formato recomendado: <code>guia-nome-do-topico.html</code>).</p>
        </div>
      </div>

      <!-- WAVE SVG DECORATIVO -->
      <svg class="wave-svg" viewBox="0 0 1440 320" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" style="width:100%;height:110px;margin-top:18px;opacity:0.95">
        <defs><linearGradient id="waveGrad2" x1="0" x2="1"><stop offset="0" stop-color="#6366f1" stop-opacity="0.12"/><stop offset="1" stop-color="#a855f7" stop-opacity="0.08"/></linearGradient></defs>
        <path fill="url(#waveGrad2)" d="M0,224L60,197.3C120,171,240,117,360,96C480,75,600,85,720,106.7C840,128,960,160,1080,176C1200,192,1320,192,1380,192L1440,192L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"></path>
      </svg>

      <?php
      // -------------------------------
      // Carregar lista de guias (PHP)
      // Preferência por incluir contador_guias.php se existir, senão varre o diretório atual.
      // -------------------------------
      $guides = [];
      $totalGuides = 0;

      // Se existir contador_guias.php, use-o (retornando array)
      if (file_exists(__DIR__ . '/contador_guias.php')) {
          $result = include __DIR__ . '/contador_guias.php';
          if (is_array($result)) {
              $totalGuides = isset($result['total']) ? intval($result['total']) : 0;
              $guides = isset($result['arquivos']) ? $result['arquivos'] : [];
          }
      } else {
          // Varre diretório atual
          $files = @scandir(__DIR__);
          if ($files !== false) {
              foreach ($files as $f) {
                  if (preg_match('/^guia-[\w\-\_]+\.(html|php)$/i', $f)) {
                      $guides[] = $f;
                  }
              }
          }
          $totalGuides = count($guides);
      }

      // Ordena alfabeticamente os guias (opcional)
      sort($guides, SORT_NATURAL | SORT_FLAG_CASE);
      ?>

      <!-- ESTATÍSTICAS RÁPIDAS -->
      <div style="margin-top:18px;display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap">
        <div class="card fade-in" style="flex:1;min-width:260px">
          <h3>Estatísticas rápidas</h3>
          <p style="color:#a1a1aa">Contagem automática de guias na pasta.</p>
          <div style="display:flex;align-items:center;gap:12px;margin-top:12px;">
            <div style="flex:1">
              <div style="color:#a1a1aa;font-size:13px">Total de guias encontrados</div>
              <div style="font-size:20px;font-weight:800;color:#e0e0e0;margin-top:6px" id="total-guides-visual"><?php echo $totalGuides; ?></div>
            </div>
            <div>
              <button class="btn" onclick="openStats()">Ver lista</button>
            </div>
          </div>
        </div>

        <div class="card fade-in" style="min-width:300px;max-width:420px">
          <h3>Comunidade</h3>
          <p style="color:#a1a1aa">Participe do Discord para tirar dúvidas, sugerir guias e colaborar.</p>
          <div style="margin-top:12px;display:flex;gap:10px;align-items:center">
            <a class="btn primary" href="https://discord.gg/kYvgJRuxTe" target="_blank" rel="noopener"><i class="fa-brands fa-discord"></i> Entrar no Discord</a>
            <button class="btn" onclick="copyInvite()">Copiar convite</button>
          </div>
        </div>
      </div>

      <!-- GUIAS ENCONTRADOS: GRADE COM ICONES -->
      <div style="margin-top:22px">
        <div class="card">
          <h3>Guias encontrados</h3>

          <?php if ($totalGuides === 0): ?>
            <p style="color:#a1a1aa">Nenhum arquivo <code>guia-*.html</code> encontrado na pasta. Coloque seus arquivos na raiz ou ajuste o padrão.</p>
          <?php else: ?>
            <div class="grid-guias">
              <?php foreach ($guides as $g):
                // extrai nome base sem prefixo e extensão
                $nomeBase = preg_replace('/^guia\-/i', '', preg_replace('/\.(html|php)$/i', '', $g));
                $iconePath = 'assets/svg/' . strtolower($nomeBase) . '.svg';
                // texto bonito (substitui hifens por espaços e capitaliza)
                $textoNome = ucfirst(str_replace('-', ' ', $nomeBase));
                // URL para o item
                $url = htmlspecialchars($g);
              ?>
                <a href="<?php echo $url; ?>" class="guia-card" title="<?php echo htmlspecialchars($textoNome); ?>">
                  <div class="guia-icon" aria-hidden="true">
                    <?php if (file_exists(__DIR__ . '/' . $iconePath)): ?>
                      <img src="<?php echo htmlspecialchars($iconePath); ?>" alt="<?php echo htmlspecialchars($textoNome); ?> icon">
                    <?php else: ?>
                      <!-- ícone fallback -->
                      <svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="#a855f7" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <rect x="3" y="3" width="18" height="18" rx="3" />
                        <path d="M8 12h8" />
                      </svg>
                    <?php endif; ?>
                  </div>
                  <div class="guia-nome"><?php echo htmlspecialchars($textoNome); ?></div>
                </a>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>

        </div>
      </div>

    </div> <!-- /wrap -->
  </main>

  <!-- FLOATING COUNTER -->
  <div id="floatingCounter" class="guide-counter-fixed float-up">
    <div style="font-size:16px;color:#cbd5ff"><i class="fa-solid fa-book"></i></div>
    <div style="font-size:13px;color:#a1a1aa">Guias</div>
    <div class="count" id="floatingGuideCount"><?php echo $totalGuides; ?></div>
  </div>

  <!-- MODAL DE ESTATÍSTICAS (mostra apenas total + lista com icones) -->
  <div id="modalStats" class="modal-overlay" onclick="closeStats(event)" aria-hidden="true">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="statsTitle">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px">
        <div>
          <h2 id="statsTitle">Estatísticas</h2>
          <div class="small">Total e lista de guias encontrados</div>
        </div>
        <button class="btn" onclick="closeStats(event)" aria-label="Fechar modal"><i class="fa-solid fa-xmark"></i></button>
      </div>

      <div style="margin-top:14px">
        <div style="font-size:13px;color:#a1a1aa">Total de guias</div>
        <div style="font-weight:800;font-size:22px;color:#e0e0e0;margin-top:6px" id="modal-total"><?php echo $totalGuides; ?></div>

        <div style="margin-top:12px;">
          <div style="color:#a1a1aa;font-size:13px;margin-bottom:8px">Guias encontrados</div>
          <?php if ($totalGuides === 0): ?>
            <div style="color:#9aa3b9">—</div>
          <?php else: ?>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
              <?php foreach ($guides as $g):
                $nomeBase = preg_replace('/^guia\-/i', '', preg_replace('/\.(html|php)$/i', '', $g));
                $iconePath = 'assets/svg/' . strtolower($nomeBase) . '.svg';
                $textoNome = ucfirst(str_replace('-', ' ', $nomeBase));
                $url = htmlspecialchars($g);
              ?>
                <a href="<?php echo $url; ?>" class="stat-item" style="text-decoration:none" title="<?php echo htmlspecialchars($textoNome); ?>">
                  <div class="icon" aria-hidden="true">
                    <?php if (file_exists(__DIR__ . '/' . $iconePath)): ?>
                      <img src="<?php echo htmlspecialchars($iconePath); ?>" alt="<?php echo htmlspecialchars($textoNome); ?>" style="width:34px;height:34px;object-fit:contain">
                    <?php else: ?>
                      <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="#a855f7" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3" /></svg>
                    <?php endif; ?>
                  </div>
                  <div class="text" style="margin-left:8px;"><?php echo htmlspecialchars($textoNome); ?></div>
                </a>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <div style="margin-top:14px;text-align:right">
        <button class="btn" onclick="closeStats(event)">Fechar</button>
      </div>
    </div>
  </div>

  <!-- RODAPÉ (mesmo estilo do index) -->
<footer class="site-footer">
  <div class="footer-content">
    <div class="footer-section">
      <div class="footer-logo">
        <div class="footer-icon">
          <img src="assets/svg/route.svg" alt="Guia de Programação">
        </div>
        <span class="footer-title">Guia de Programação</span>
      </div>
      <p class="footer-description">
        Coleção moderna de tutoriais e referências para desenvolvedores.
      </p>
    </div>
    
<div class="footer-section">
  <h4>Guias Populares</h4>
  <div class="footer-links">
    <a href="guia-javascript.html">JavaScript</a>
    <a href="guia-nodejs.html">Node.js</a>
    <a href="guia-python.html">Python</a>
    <a href="guia-react.html">React</a>
    <a href="guia-php.html">PHP</a>
  </div>
</div>
    
    <div class="footer-section">
      <h4>Categorias</h4>
      <div class="footer-links">
        <a href="#frontend">Front-end</a>
        <a href="#backend">Back-end</a>
        <a href="#devops">DevOps</a>
        <a href="#fullstack">Full Stack</a>
      </div>
    </div>
    
    <div class="footer-section">
      <h4>Recursos</h4>
      <div class="footer-links">
        <a href="biblioteca-projetos.html">Biblioteca</a>
        <a href="#" onclick="showAboutModal()">Sobre</a>
        <a href="#" onclick="shareContent()">Compartilhar</a>
        <a href="#" onclick="showRatingModal()">Avaliar</a>
      </div>
    </div>
  </div>
  
  <div class="footer-bottom">
    <div class="footer-divider"></div>
    <div class="footer-copyright">
      <p>
        © 2025 <strong>Guia de Programação | Systems_Bsi</strong> — Todos os direitos reservados.
      </p>
      <p class="powered-by">
        Powered by 
        <a href="https://github.com/maelgamer998" class="author-link">
          <strong>MAEL</strong>
        </a>
      </p>
    </div>
  </div>
</footer>

      <style>
    .site-footer {
      background: rgba(15, 23, 42, 0.95);
      backdrop-filter: blur(20px);
      color: #e0e0e0;
      padding: 40px 24px 20px;
      font-family: 'Poppins', sans-serif;
    }

    .footer-content {
      max-width: 1100px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 32px;
      margin-bottom: 30px;
    }

    .footer-section h4 {
      font-size: 14px;
      font-weight: 600;
      color: #fff;
      text-transform: uppercase;
      margin-bottom: 12px;
      letter-spacing: 0.5px;
    }

    .footer-links {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .footer-links a {
      color: #a1a1aa;
      font-size: 14px;
      text-decoration: none;
      transition: all 0.25s ease;
      position: relative;
    }

    .footer-links a:hover {
      color: #fff;
      transform: translateX(4px);
    }

    .footer-logo {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 12px;
    }

    .footer-icon {
      width: 44px;
      height: 44px;
      border-radius: 8px;
      background: linear-gradient(135deg,#6366f1,#a855f7);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 6px;
    }

    .footer-icon img {
      width: 20px;
      filter: brightness(0) invert(1);
    }

    .footer-title {
      font-weight: 700;
      background: linear-gradient(90deg,#60a5fa,#a78bfa);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      font-size: 16px;
    }

    .footer-description {
      font-size: 13px;
      color: #a1a1aa;
      line-height: 1.5;
    }

    .footer-bottom {
      max-width: 1100px;
      margin: 0 auto;
      text-align: center;
      font-size: 13px;
      color: #6b7280;
    }

    .footer-divider {
      height: 1px;
      margin-bottom: 12px;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.05), transparent);
    }

    .author-link {
      color: #c7d2fe;
      text-decoration: none;
      transition: color 0.3s ease;
    }

    .author-link:hover {
      color: #fff;
    }

    /* Responsivo */
    @media(max-width:768px){
      .footer-content {
        grid-template-columns: 1fr 1fr;
        gap: 20px;
      }
      .footer-logo-section {
        grid-column: span 2;
      }
    }

    @media(max-width:480px){
      .footer-content {
        grid-template-columns: 1fr;
      }
      .footer-logo-section {
        grid-column: span 1;
      }
    }
  </style>
  <script>
function copyInvite() {
  const invite = 'https://discord.gg/kYvgJRuxTe';
  navigator.clipboard?.writeText(invite)
    .then(() => showCopiedToast())
    .catch(() => {
      showCopiedToast();
    });
}

function showCopiedToast() {
  const toast = document.getElementById("copyNotification");
  if (!toast) return;
  toast.classList.add("show");
  // remove após 3 segundos
  setTimeout(() => toast.classList.remove("show"), 3000);
}

    // Modal controls
    const modal = document.getElementById('modalStats');
    function openStats(){
      modal.style.display = 'flex';
      modal.setAttribute('aria-hidden','false');
      document.body.style.overflow = 'hidden';
    }
    function closeStats(e){
      // fecha apenas se clicar no overlay ou no botão
      if (!e) return;
      if (e.target === modal || e.type === 'click' || e.currentTarget === modal) {
        modal.style.display = 'none';
        modal.setAttribute('aria-hidden','true');
        document.body.style.overflow = '';
      }
    }
    document.addEventListener('keydown', (ev) => {
      if (ev.key === 'Escape') {
        modal.style.display = 'none';
        document.body.style.overflow = '';
      }
    });

    // mostra o contador flutuante após load
    window.addEventListener('load', function(){
      const el = document.getElementById('floatingCounter');
      if (el) {
        el.classList.add('show');
      }
    });

    // Accessibility: trap from tabbing out of modal (simple)
    modal.addEventListener('keydown', function(e){
      if (e.key === 'Tab') {
        // basic prevent scrolling away
        e.stopPropagation();
      }
    });

    // Optional: busca dinâmica do contador via fetch se preferir (uncomment se usar contador_guias.php)
    /*
    async function atualizarContador() {
      try {
        const res = await fetch('contador_guias.php');
        if (!res.ok) return;
        const data = await res.json();
        document.getElementById('floatingGuideCount').textContent = data.total;
        document.getElementById('total-guides-visual').textContent = data.total;
        document.getElementById('modal-total').textContent = data.total;
      } catch(e) { console.error(e); }
    }
    window.addEventListener('DOMContentLoaded', atualizarContador);
    */
  </script>
</body>
</html>

