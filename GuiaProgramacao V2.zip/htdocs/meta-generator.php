<?php
class MetaGenerator {
    private $pageTitle;
    private $pageDescription;
    private $pageImage;
    private $pageUrl;
    private $baseUrl = 'https://guiaprogramacao.free.nf';

    public function __construct($title = '', $description = '', $image = '') {
        $this->pageTitle = $title ?: 'Guias de Programação — Systems_Bsi';
        $this->pageDescription = $description ?: 'Coleção moderna e minimalista de tutoriais e referências para desenvolvedores.';
        $this->pageImage = $image ?: $this->baseUrl . '/assets/img/logo.png';
        $this->pageUrl = $this->getCurrentUrl();
    }

    public function generateMetaTags() {
        $tags = [];
        
        // Meta tags básicas
        $tags[] = '<meta charset="UTF-8">';
        $tags[] = '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
        $tags[] = '<meta name="description" content="' . htmlspecialchars($this->pageDescription) . '">';
        $tags[] = '<meta name="keywords" content="Programação, Tutoriais, Desenvolvimento, Front-end, Back-end, DevOps, Full Stack">';
        $tags[] = '<meta name="theme-color" content="#0a92d1">';
        $tags[] = '<meta name="robots" content="index, follow">';

        // Open Graph
        $tags[] = '<meta property="og:title" content="' . htmlspecialchars($this->pageTitle) . '">';
        $tags[] = '<meta property="og:description" content="' . htmlspecialchars($this->pageDescription) . '">';
        $tags[] = '<meta property="og:image" content="' . $this->pageImage . '">';
        $tags[] = '<meta property="og:url" content="' . $this->pageUrl . '">';
        $tags[] = '<meta property="og:type" content="website">';
        $tags[] = '<meta property="og:site_name" content="Guias de Programação">';

        // Twitter Cards
        $tags[] = '<meta name="twitter:card" content="summary_large_image">';
        $tags[] = '<meta name="twitter:title" content="' . htmlspecialchars($this->pageTitle) . '">';
        $tags[] = '<meta name="twitter:description" content="' . htmlspecialchars($this->pageDescription) . '">';
        $tags[] = '<meta name="twitter:image" content="' . $this->pageImage . '">';

        // Canonical
        $tags[] = '<link rel="canonical" href="' . $this->pageUrl . '">';

        return implode("\n    ", $tags);
    }

    public function generateStructuredData() {
        $structuredData = [
            "@context" => "https://schema.org",
            "@type" => "WebSite",
            "name" => $this->pageTitle,
            "url" => $this->pageUrl,
            "description" => $this->pageDescription,
            "publisher" => [
                "@type" => "Organization",
                "name" => "Systems_Bsi",
                "logo" => [
                    "@type" => "ImageObject",
                    "url" => $this->baseUrl . '/assets/img/logo.png'
                ]
            ]
        ];

        return '<script type="application/ld+json">' . json_encode($structuredData) . '</script>';
    }

    private function getCurrentUrl() {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
        return $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    }
}

// Uso em cada página PHP:
// $metaGenerator = new MetaGenerator($pageTitle, $pageDescription, $pageImage);
// echo $metaGenerator->generateMetaTags();
// echo $metaGenerator->generateStructuredData();
?>