<?php
// contador_guias.php
// Conta automaticamente quantos arquivos "guia-*.html" e "guia-*.php" existem na pasta atual.

// Caminho do diretório onde estão os guias (pode ajustar se quiser outra pasta)
$dir = __DIR__;

// Scaneia o diretório
$arquivos = @scandir($dir);
$total = 0;
$lista = [];

// Se houver arquivos, filtra os guias
if ($arquivos !== false) {
    foreach ($arquivos as $arquivo) {
        if (preg_match('/^guia-[\w\-_]+\.(html|php)$/i', $arquivo)) {
            $lista[] = $arquivo;
        }
    }
    $total = count($lista);
}

// Se for acessado diretamente pelo navegador, exibe um JSON
if (basename($_SERVER['SCRIPT_FILENAME']) === basename(__FILE__)) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'total' => $total,
        'arquivos' => $lista
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// Caso contrário (se incluído), apenas retorna a variável
return [
    'total' => $total,
    'arquivos' => $lista
];
?>
