// meta.js - VERSÃO CORRIGIDA
console.log('📦 Carregando MetaManager...');

class MetaManager {
    constructor() {
        console.log('🔧 MetaManager constructor executado');
        this.baseUrl = 'https://guiaprogramacao.free.nf';
        this.defaultImage = 'https://guiaprogramacao.free.nf/assets/img/logo.png';
        this.defaultDescription = 'Coleção moderna e minimalista de tutoriais e referências para desenvolvedores Front-end, Back-end, DevOps e Full Stack.';
        
        this.preRenderMetas();
    }

    preRenderMetas() {
        console.log('🚀 Pré-renderizando meta tags...');
        
        const criticalMetas = [
            // Open Graph
            { property: 'og:title', content: this.getInitialTitle() },
            { property: 'og:description', content: this.getInitialDescription() },
            { property: 'og:image', content: this.defaultImage },
            { property: 'og:url', content: this.getCurrentUrl() },
            { property: 'og:type', content: 'website' },
            { property: 'og:site_name', content: 'Guias de Programação' },
            { property: 'og:locale', content: 'pt_BR' },
            
            // Twitter Cards
            { name: 'twitter:card', content: 'summary_large_image' },
            { name: 'twitter:title', content: this.getInitialTitle() },
            { name: 'twitter:description', content: this.getInitialDescription() },
            { name: 'twitter:image', content: this.defaultImage },
            { name: 'twitter:site', content: '@Systems_Bsi' },
            { name: 'twitter:creator', content: '@Systems_Bsi' },
            
            // Basic Meta
            { name: 'description', content: this.getInitialDescription() },
            { name: 'keywords', content: 'programação, desenvolvimento, frontend, backend, devops, javascript, html, css, nodejs, python, react, sql, git, docker' }
        ];

        criticalMetas.forEach(meta => {
            this.forceCreateMeta(meta);
        });

        this.injectStructuredData();
    }

    forceCreateMeta(metaConfig) {
        const attribute = metaConfig.property ? 'property' : 'name';
        const value = metaConfig.property || metaConfig.name;
        const content = metaConfig.content;

        const existing = document.querySelector(`meta[${attribute}="${value}"]`);
        if (existing) existing.remove();

        const meta = document.createElement('meta');
        if (attribute === 'property') {
            meta.setAttribute('property', value);
        } else {
            meta.setAttribute('name', value);
        }
        meta.setAttribute('content', content);
        document.head.appendChild(meta);
    }

    getInitialTitle() {
        const path = window.location.pathname;
        const titles = {
            '/': 'Guias de Programação — Systems_Bsi',
            '/index.html': 'Guias de Programação — Systems_Bsi',
            '/guia-javascript.html': 'Guia JavaScript Completo — Systems_Bsi',
            '/guia-html-css-js.html': 'Guia HTML, CSS e JavaScript — Systems_Bsi',
            '/guia-nodejs.html': 'Guia Node.js — Systems_Bsi',
            '/guia-react.html': 'Guia React.js — Systems_Bsi',
            '/guia-python.html': 'Guia Python — Systems_Bsi'
        };
        
        return titles[path] || document.title || 'Guias de Programação — Systems_Bsi';
    }

    getInitialDescription() {
        const path = window.location.pathname;
        const descriptions = {
            '/': 'Coleção moderna de tutoriais e referências para desenvolvedores Front-end, Back-end, DevOps e Full Stack.',
            '/index.html': 'Coleção moderna de tutoriais e referências para desenvolvedores Front-end, Back-end, DevOps e Full Stack.',
            '/guia-javascript.html': 'Aprenda JavaScript moderno do básico ao avançado. DOM, ES6+, Async/Await, Promises e muito mais.',
            '/guia-html-css-js.html': 'Domine o desenvolvimento web front-end com HTML5, CSS3 e JavaScript. Sites responsivos e modernos.',
            '/guia-nodejs.html': 'Crie APIs REST, servidores e aplicações backend com Node.js. Express, MongoDB, JWT e mais.',
            '/guia-react.html': 'Desenvolva interfaces modernas com React.js. Hooks, Context API, Redux e componentes reutilizáveis.',
            '/guia-python.html': 'Aprenda Python para web, dados, automação e muito mais. Django, Flask, Pandas e Scikit-learn.'
        };
        
        return descriptions[path] || this.defaultDescription;
    }

    getCurrentUrl() {
        return window.location.href;
    }

    injectStructuredData() {
        const structuredData = {
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": "Guias de Programação",
            "url": this.getCurrentUrl(),
            "description": this.getInitialDescription(),
            "publisher": {
                "@type": "Organization",
                "name": "Systems_Bsi"
            }
        };

        const existingScript = document.querySelector('script[type="application/ld+json"]');
        if (existingScript) existingScript.remove();

        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.textContent = JSON.stringify(structuredData);
        document.head.appendChild(script);
    }

    // 🔧 MÉTODO DEBUG ADICIONADO
    debug() {
        console.log('🔍 Debug MetaManager:');
        console.log('- Current URL:', this.getCurrentUrl());
        console.log('- Page Title:', this.getInitialTitle());
        console.log('- Page Description:', this.getInitialDescription());
        console.log('- Default Image:', this.defaultImage);
        
        // Verificar meta tags importantes
        const importantTags = [
            'description',
            'og:title', 'og:description', 'og:image', 'og:url',
            'twitter:title', 'twitter:description', 'twitter:image'
        ];
        
        importantTags.forEach(tag => {
            const selector = tag.startsWith('og:') ? 
                `meta[property="${tag}"]` : `meta[name="${tag}"]`;
            const element = document.querySelector(selector);
            console.log(`- ${tag}:`, element ? `"${element.getAttribute('content')}"` : '❌ NÃO ENCONTRADO');
        });
        
        console.log('- Total meta tags:', document.querySelectorAll('meta').length);
    }

    // Método para verificar se as meta tags estão funcionando
    testSharing() {
        console.log('🧪 Teste de Compartilhamento:');
        console.log('📱 Copie esta URL e teste no WhatsApp/Facebook:');
        console.log(this.getCurrentUrl());
        console.log('🔗 Ferramentas de teste:');
        console.log('- Facebook: https://developers.facebook.com/tools/debug/');
        console.log('- Twitter: https://cards-dev.twitter.com/validator');
    }
}

console.log('✅ MetaManager class definida');