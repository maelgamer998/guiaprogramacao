/* security-system.js
   Versão: 2.2
   Integra com modo admin via cookie gp_admin=true
   Inclui proteções, detecção de DevTools e helpers para carregar conteúdo protegido.
*/

class SecuritySystem {
    constructor(options = {}) {
        this.encryptionKeyPrefix = options.keyPrefix || 'guia-programacao-';
        this.securityLevel = options.securityLevel || 'high';
        this.adminBypassCookie = options.adminCookieName || 'gp_admin';
        this.adminBypass = this.checkAdminBypass();
        this.init();
    }

    checkAdminBypass() {
        try {
            const cookies = document.cookie.split(';').map(c => c.trim());
            return cookies.some(c => c.startsWith(`${this.adminBypassCookie}=`) && c.split('=')[1] === 'true');
        } catch {
            return false;
        }
    }

    init() {
        if (this.adminBypass) {
            console.info('🔧 SecuritySystem: modo admin (bypass) ativo — proteções desativadas para desenvolvimento.');
        } else {
            console.info('🛡️ SecuritySystem: proteções ativas');
        }
        this.applySecurityStyles();
        if (!this.adminBypass) {
            this.setupEventProtection();
            this.setupDevToolsDetection();
            this.setupContentProtection();
            this.setupResourceProtection();
        }
        this.createFloatingShield();
    }

    applySecurityStyles() {
        const css = `
            /* minimal styles for overlays/toasts/shield */
            .security-overlay{position:fixed;inset:0;background:rgba(8,10,15,0.85);display:flex;align-items:center;justify-content:center;z-index:2147483647}
            .security-modal{background:#0b1220;color:#e6eef8;padding:24px;border-radius:12px;max-width:560px;box-shadow:0 10px 40px rgba(0,0,0,0.6);text-align:center}
            .security-toast{position:fixed;top:20px;right:20px;padding:12px 16px;border-radius:10px;background:#ff726f;color:white;z-index:2147483646;box-shadow:0 8px 20px rgba(0,0,0,0.3)}
            .floating-shield{position:fixed;left:20px;bottom:20px;width:56px;height:56px;border-radius:12px;background:linear-gradient(135deg,#6366f1,#a855f7);display:flex;align-items:center;justify-content:center;color:white;cursor:pointer;z-index:2147483645;box-shadow:0 8px 24px rgba(0,0,0,0.3)}
            .protected-content{user-select:none!important;pointer-events:auto}
        `;
        const s = document.createElement('style');
        s.textContent = css;
        document.head.appendChild(s);
    }

    getSVGShield() {
        return `<svg viewBox="0 0 24 24" width="36" height="36" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L4 5v6c0 5.523 3.582 10.561 8 12 4.418-1.439 8-6.477 8-12V5l-8-3z" fill="white" opacity="0.12"/><path d="M9 12l2 2 4-4" stroke="white" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    }

    createFloatingShield() {
        const shield = document.createElement('div');
        shield.className = 'floating-shield';
        shield.id = 'floatingShield';
        shield.innerHTML = this.getSVGShield();
        shield.title = 'PinguSys • Proteção ativa — clique para status';
        shield.addEventListener('click', () => this.showSecurityStatus());
        document.body.appendChild(shield);
    }

    showSecurityToast(message, type='error') {
        const t = document.createElement('div');
        t.className = 'security-toast';
        t.textContent = message;
        document.body.appendChild(t);
        setTimeout(()=> {
            t.style.transition = 'opacity .3s';
            t.style.opacity = '0';
            setTimeout(()=> t.remove(), 400);
        }, 3200);
    }

    showSecurityOverlay(title='Proteção', message='Ação não permitida') {
        if (document.querySelector('.security-overlay')) return;
        const overlay = document.createElement('div');
        overlay.className = 'security-overlay';
        overlay.innerHTML = `<div class="security-modal"><h2 style="margin:0 0 12px">${title}</h2><p style="margin:0 0 8px">${message}</p><button id="securityCloseBtn" style="margin-top:12px;padding:8px 12px;border-radius:8px;border:none;cursor:pointer;background:#6366f1;color:white">Fechar</button></div>`;
        document.body.appendChild(overlay);
        document.body.style.overflow = 'hidden';
        overlay.querySelector('#securityCloseBtn').addEventListener('click', ()=> this.removeOverlay(overlay));
        overlay.addEventListener('click', (e)=> { if(e.target === overlay) this.removeOverlay(overlay); });
    }

    removeOverlay(overlay) {
        overlay.remove();
        document.body.style.overflow = '';
    }

    setupEventProtection() {
        // bloquear teclas
        document.addEventListener('keydown', (e) => {
            const blocked = (
                e.key === 'F12' ||
                (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J' || e.key === 'C')) ||
                (e.ctrlKey && e.key === 'U') ||
                (e.ctrlKey && e.key === 'S') ||
                (e.ctrlKey && e.key === 'P')
            );
            if (blocked) {
                e.preventDefault();
                e.stopPropagation();
                this.showSecurityToast('Ação restrita (devtools/desenvolvimento)', 'warning');
                return false;
            }
        }, {passive:false});

        // contexto e seleção
        document.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            this.showSecurityToast('Menu de contexto desativado', 'warning');
        });
        document.addEventListener('selectstart', (e) => {
            if (!e.target.closest('input, textarea, [contenteditable="true"]')) {
                e.preventDefault();
            }
        }, {passive:false});
        document.addEventListener('dragstart', (e) => {
            if (e.target.tagName === 'IMG') e.preventDefault();
        });
        document.addEventListener('copy', (e) => {
            // Permite copiar em inputs; quando bloqueado, mostra toast
            if (!this.isAllowedCopy(e.target)) {
                e.preventDefault();
                this.showSecurityToast('Conteúdo protegido contra cópia', 'warning');
            }
        });
    }

    isAllowedCopy(target) {
        if (!target) return false;
        if (target.closest && target.closest('input, textarea, [contenteditable="true"]')) return true;
        return false;
    }

    setupDevToolsDetection() {
        // heurística de tamanho e debugger
        let lastW = innerWidth, lastH = innerHeight;
        setInterval(() => {
            const w = innerWidth, h = innerHeight;
            if (Math.abs(w-lastW) > 120 || Math.abs(h-lastH) > 120) {
                this.showSecurityOverlay('Proteção Ativada', 'Possível abertura das ferramentas de desenvolvimento detectada.');
            }
            lastW = w; lastH = h;
        }, 700);

        setInterval(() => {
            const start = performance.now();
            // alerta: debugger pode travar UX para devs
            try { debugger; } catch(e) {}
            const delta = performance.now() - start;
            if (delta > 200) {
                this.showSecurityOverlay('Proteção Ativada', 'Debugger detectado. Acesso restrito.');
            }
        }, 1200);
    }

    setupContentProtection() {
        // marca elementos principais como protegidos
        const selectors = `h1,h2,h3,h4,h5,h6,.card,.hero,.guide-content,.code-block,.example,.tutorial`;
        document.querySelectorAll(selectors).forEach(el => el.classList.add('protected-content'));

        // imagens não arrastáveis
        document.querySelectorAll('img').forEach(img => {
            img.setAttribute('draggable', 'false');
            img.style.userSelect = 'none';
            img.style.pointerEvents = 'auto';
        });

        // adiciona watermark discreto (visível) com o hostname
        this.addWatermark();
    }

    setupResourceProtection() {
        // prevenir uso em iframes
        if (window.self !== window.top) {
            this.showSecurityOverlay('Acesso Bloqueado', 'Embedding desta página não é permitido');
        }

        // bloquear impressão
        window.addEventListener('beforeprint', (e) => {
            e.preventDefault();
            this.showSecurityToast('Impressão não autorizada', 'warning');
        });
    }

    addWatermark() {
        if (document.querySelector('.security-watermark')) return;
        const w = document.createElement('div');
        w.className = 'security-watermark';
        w.style.position = 'fixed';
        w.style.pointerEvents = 'none';
        w.style.opacity = '0.06';
        w.style.top = '20%';
        w.style.left = '10%';
        w.style.fontSize = '72px';
        w.style.color = '#000';
        w.style.transform = 'rotate(-20deg)';
        w.style.zIndex = '9999';
        w.textContent = `${window.location.hostname} • PinguSys`;
        document.body.appendChild(w);
    }

    showSecurityStatus() {
        if (this.adminBypass) {
            this.showSecurityToast('Modo admin: proteções desativadas', 'success');
            return;
        }
        const st = this.getSecurityStatus();
        this.showSecurityOverlay('Segurança Ativa', `Nível: ${st.level}<br>Proteções habilitadas: ${st.features.join(', ')}`);
    }

    getSecurityStatus() {
        return {
            level: this.securityLevel,
            version: '2.2',
            features: ['contextMenuBlock','textSelectionRestrict','devToolsDetect','copyProtect','watermark']
        };
    }

    // Helper: carrega conteúdo protegido via API (requer token JWT)
    async loadProtectedGuide(guideId, opts = {}) {
        const container = document.querySelector(opts.selector || '#protected-area');
        if (!container) return;
        container.innerHTML = 'Carregando conteúdo protegido...';

        try {
            const token = opts.token || this.getAuthToken(); // token pode vir de cookie/localStorage
            const res = await fetch(`/api/guide/${encodeURIComponent(guideId)}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': token ? `Bearer ${token}` : ''
                },
                credentials: 'include'
            });

            if (res.status === 401 || res.status === 403) {
                container.innerHTML = '<p>🔒 Acesso negado. Faça login para ver o conteúdo.</p>';
                return;
            }

            if (!res.ok) {
                container.innerHTML = `<p>Erro ${res.status} ao carregar o conteúdo.</p>`;
                return;
            }

            const json = await res.json();
            // json.html contém o conteúdo HTML seguro (assuma sanitized pelo servidor)
            container.innerHTML = json.html || '<p>Conteúdo indisponível</p>';
            // aplicar marcação de proteção a novo conteúdo
            document.querySelectorAll('#protected-area img').forEach(i => i.setAttribute('draggable','false'));
            document.querySelectorAll('#protected-area pre, #protected-area code').forEach(el => el.classList.remove('protected-content')); // permitir seleção de código opcional
        } catch (err) {
            console.error(err);
            container.innerHTML = '<p>Erro ao buscar conteúdo.</p>';
        }
    }

    getAuthToken() {
        // exemplo: token em cookie 'gp_jwt'
        const match = document.cookie.match(/gp_jwt=([^;]+)/);
        return match ? decodeURIComponent(match[1]) : null;
    }
}

/* Inicializa automaticamente */
(function() {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => window.securitySystem = new SecuritySystem());
    } else {
        window.securitySystem = new SecuritySystem();
    }
})();
