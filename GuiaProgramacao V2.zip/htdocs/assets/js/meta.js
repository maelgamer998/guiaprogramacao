class SecuritySystem {
    constructor() {
        this.encryptionKey = 'guia-programacao-' + window.location.hostname;
        this.securityLevel = 'high';
        this.init();
    }

    init() {
        console.log('🛡️ Iniciando Sistema de Segurança...');
        this.applySecurityStyles();
        this.setupEventProtection();
        this.setupDevToolsDetection();
        this.setupContentProtection();
        this.setupResourceProtection();
        this.createFloatingShield();
    }

    applySecurityStyles() {
        const securityStyles = `
            .security-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: linear-gradient(135deg, rgba(15, 23, 42, 0.98), rgba(30, 30, 50, 0.97));
                backdrop-filter: blur(20px);
                z-index: 2147483647;
                display: flex;
                align-items: center;
                justify-content: center;
                font-family: 'Poppins', Arial, sans-serif;
                animation: securityFadeIn 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            }

            .security-modal {
                background: linear-gradient(135deg, rgba(20, 20, 35, 0.95), rgba(30, 30, 50, 0.9));
                border: 2px solid;
                border-image: linear-gradient(135deg, #6366f1, #a855f7, #ec4899) 1;
                border-radius: 20px;
                padding: 40px;
                max-width: 500px;
                width: 90%;
                text-align: center;
                box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5);
                position: relative;
                overflow: hidden;
            }

            .security-modal::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 4px;
                background: linear-gradient(90deg, #6366f1, #a855f7, #ec4899);
                animation: gradientShift 3s ease infinite;
            }

            .security-icon {
                width: 80px;
                height: 80px;
                margin: 0 auto 20px;
                animation: iconPulse 2s ease-in-out infinite;
                filter: drop-shadow(0 4px 12px rgba(99, 102, 241, 0.4));
            }

            .security-title {
                font-size: 1.8rem;
                font-weight: 700;
                margin-bottom: 15px;
                background: linear-gradient(135deg, #60a5fa, #a78bfa, #ec4899);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-size: 200% auto;
                animation: titleShimmer 3s ease-in-out infinite;
            }

            .security-message {
                color: #e0e0e0;
                font-size: 1.1rem;
                line-height: 1.6;
                margin-bottom: 25px;
            }

            .security-details {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 12px;
                padding: 15px;
                margin: 20px 0;
                font-size: 0.9rem;
                color: #a1a1aa;
            }

            .security-timer {
                font-size: 2rem;
                font-weight: 700;
                color: #a78bfa;
                margin: 20px 0;
                animation: countdownPulse 1s ease-in-out infinite;
            }

            .security-footer {
                margin-top: 25px;
                padding-top: 20px;
                border-top: 1px solid rgba(255, 255, 255, 0.1);
                color: #6b7280;
                font-size: 0.8rem;
            }

            .security-toast {
                position: fixed;
                top: 20px;
                right: 20px;
                background: linear-gradient(135deg, rgba(239, 68, 68, 0.95), rgba(220, 38, 38, 0.9));
                color: white;
                padding: 15px 20px;
                border-radius: 12px;
                z-index: 2147483646;
                font-family: 'Poppins', Arial, sans-serif;
                box-shadow: 0 8px 25px rgba(239, 68, 68, 0.3);
                animation: slideInRight 0.3s ease;
                border-left: 4px solid #fca5a5;
                backdrop-filter: blur(10px);
                display: flex;
                align-items: center;
                gap: 10px;
            }

            .security-toast.warning {
                background: linear-gradient(135deg, rgba(245, 158, 11, 0.95), rgba(217, 119, 6, 0.9));
                border-left-color: #fdba74;
                box-shadow: 0 8px 25px rgba(245, 158, 11, 0.3);
            }

            .security-toast.info {
                background: linear-gradient(135deg, rgba(59, 130, 246, 0.95), rgba(37, 99, 235, 0.9));
                border-left-color: #93c5fd;
                box-shadow: 0 8px 25px rgba(59, 130, 246, 0.3);
            }

            .security-toast.success {
                background: linear-gradient(135deg, rgba(34, 197, 94, 0.95), rgba(21, 128, 61, 0.9));
                border-left-color: #86efac;
                box-shadow: 0 8px 25px rgba(34, 197, 94, 0.3);
            }

            .toast-icon {
                width: 20px;
                height: 20px;
                flex-shrink: 0;
            }

			.floating-shield {
    			position: fixed;
    			bottom: 20px;
    			left: 20px; /* Alterado de right para left */
    			width: 60px;
    			height: 60px;
    			z-index: 2147483645;
    			animation: floatShield 3s ease-in-out infinite;
    			cursor: pointer;
    			opacity: 0.7;
    			transition: all 0.3s ease;
			}

            .floating-shield:hover {
                opacity: 1;
                transform: scale(1.1);
            }

            .protected-content {
                -webkit-user-select: none !important;
                -moz-user-select: none !important;
                -ms-user-select: none !important;
                user-select: none !important;
                -webkit-touch-callout: none !important;
                -webkit-tap-highlight-color: transparent !important;
                cursor: default !important;
            }

            .allow-selection {
                -webkit-user-select: text !important;
                -moz-user-select: text !important;
                -ms-user-select: text !important;
                user-select: text !important;
            }

            .security-watermark {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                pointer-events: none;
                background: 
                    repeating-linear-gradient(
                        45deg,
                        transparent,
                        transparent 100px,
                        rgba(99, 102, 241, 0.02) 100px,
                        rgba(99, 102, 241, 0.02) 200px
                    ),
                    repeating-linear-gradient(
                        -45deg,
                        transparent,
                        transparent 150px,
                        rgba(168, 85, 247, 0.02) 150px,
                        rgba(168, 85, 247, 0.02) 300px
                    );
                z-index: 9998;
                opacity: 0.3;
                animation: watermarkFloat 20s linear infinite;
            }

            @keyframes securityFadeIn {
                from { 
                    opacity: 0; 
                    backdrop-filter: blur(0px);
                }
                to { 
                    opacity: 1; 
                    backdrop-filter: blur(20px);
                }
            }

            @keyframes gradientShift {
                0%, 100% { background-position: 0% 50%; }
                50% { background-position: 100% 50%; }
            }

            @keyframes iconPulse {
                0%, 100% { transform: scale(1) rotate(0deg); }
                50% { transform: scale(1.1) rotate(5deg); }
            }

            @keyframes titleShimmer {
                0%, 100% { background-position: 0% 50%; }
                50% { background-position: 100% 50%; }
            }

            @keyframes countdownPulse {
                0%, 100% { opacity: 1; transform: scale(1); }
                50% { opacity: 0.7; transform: scale(1.05); }
            }

            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }

            @keyframes floatShield {
                0%, 100% { transform: translateY(0px) rotate(0deg); }
                50% { transform: translateY(-10px) rotate(5deg); }
            }

            @keyframes watermarkFloat {
                0% { background-position: 0 0; }
                100% { background-position: 400px 400px; }
            }

            @keyframes shieldGlow {
                0%, 100% { filter: drop-shadow(0 0 5px rgba(99, 102, 241, 0.5)); }
                50% { filter: drop-shadow(0 0 15px rgba(99, 102, 241, 0.8)); }
            }
        `;

        const styleSheet = document.createElement('style');
        styleSheet.textContent = securityStyles;
        document.head.appendChild(styleSheet);
    }

    getSecuritySVG(type) {
        const svgs = {
            shield: `
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2L4 5V11C4 16.55 7.84 21.74 12 23C16.16 21.74 20 16.55 20 11V5L12 2Z" 
                          fill="url(#shieldGradient)" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M9 12L11 14L15 10" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <defs>
                        <linearGradient id="shieldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#6366f1"/>
                            <stop offset="100%" stop-color="#a855f7"/>
                        </linearGradient>
                    </defs>
                </svg>
            `,
            warning: `
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 9V13M12 17H12.01M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" 
                          stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <defs>
                        <linearGradient id="warningGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#f59e0b"/>
                            <stop offset="100%" stop-color="#d97706"/>
                        </linearGradient>
                    </defs>
                </svg>
            `,
            lock: `
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" 
                          fill="url(#lockGradient)" stroke="currentColor" stroke-width="2"/>
                    <path d="M7 11V7C7 4.23858 9.23858 2 12 2C14.7614 2 17 4.23858 17 7V11" 
                          stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <circle cx="12" cy="15" r="1" fill="currentColor"/>
                    <defs>
                        <linearGradient id="lockGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#ec4899"/>
                            <stop offset="100%" stop-color="#be185d"/>
                        </linearGradient>
                    </defs>
                </svg>
            `,
            block: `
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="10" 
                            fill="url(#blockGradient)" stroke="currentColor" stroke-width="2"/>
                    <path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <defs>
                        <linearGradient id="blockGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#ef4444"/>
                            <stop offset="100%" stop-color="#dc2626"/>
                        </linearGradient>
                    </defs>
                </svg>
            `,
            info: `
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="10" 
                            fill="url(#infoGradient)" stroke="currentColor" stroke-width="2"/>
                    <path d="M12 16V12M12 8H12.01" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <defs>
                        <linearGradient id="infoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#3b82f6"/>
                            <stop offset="100%" stop-color="#1d4ed8"/>
                        </linearGradient>
                    </defs>
                </svg>
            `,
            success: `
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="10" 
                            fill="url(#successGradient)" stroke="currentColor" stroke-width="2"/>
                    <path d="M9 12L11 14L15 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <defs>
                        <linearGradient id="successGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#10b981"/>
                            <stop offset="100%" stop-color="#059669"/>
                        </linearGradient>
                    </defs>
                </svg>
            `
        };

        return svgs[type] || svgs.shield;
    }

    createFloatingShield() {
        const shield = document.createElement('div');
        shield.className = 'floating-shield';
        shield.innerHTML = this.getSecuritySVG('shield');
        shield.style.color = '#6366f1';
        shield.style.animation = 'floatShield 3s ease-in-out infinite, shieldGlow 2s ease-in-out infinite';
        
        shield.addEventListener('click', () => {
            this.showSecurityStatus();
        });

        document.body.appendChild(shield);
    }

    setupEventProtection() {
        document.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            this.showSecurityOverlay('context_menu', 'Navegação protegida');
        });

        document.addEventListener('selectstart', (e) => {
            if (!e.target.closest('input, textarea, [contenteditable="true"]')) {
                e.preventDefault();
                this.showSecurityToast('Seleção de texto desativada', 'warning');
            }
        });

        document.addEventListener('dragstart', (e) => {
            if (e.target.tagName === 'IMG') {
                e.preventDefault();
                this.showSecurityToast('Imagens protegidas', 'info');
            }
        });

        document.addEventListener('keydown', (e) => {
            const blockedCombinations = [
                { key: 'F12', code: 123 },
                { key: 'I', code: 73, ctrl: true, shift: true },
                { key: 'J', code: 74, ctrl: true, shift: true },
                { key: 'C', code: 67, ctrl: true, shift: true },
                { key: 'U', code: 85, ctrl: true },
                { key: 'S', code: 83, ctrl: true },
                { key: 'P', code: 80, ctrl: true }
            ];

            for (const combo of blockedCombinations) {
                if (e.keyCode === combo.code &&
                    (!combo.ctrl || e.ctrlKey) &&
                    (!combo.shift || e.shiftKey)) {
                    e.preventDefault();
                    this.showSecurityOverlay('dev_tools', 'Acesso restrito');
                    return false;
                }
            }
        });

        document.addEventListener('copy', (e) => {
            if (!this.isAllowedCopy(e.target)) {
                e.preventDefault();
                this.showSecurityToast('Conteúdo protegido contra cópia', 'warning');
            }
        });
    }

    setupDevToolsDetection() {
        let lastWidth = window.innerWidth;
        let lastHeight = window.innerHeight;

        const checkWindowSize = () => {
            const widthDiff = Math.abs(window.innerWidth - lastWidth);
            const heightDiff = Math.abs(window.innerHeight - lastHeight);

            if (widthDiff > 100 || heightDiff > 100) {
                this.showSecurityOverlay('dev_tools_detected', 'Ferramentas de desenvolvimento detectadas');
            }

            lastWidth = window.innerWidth;
            lastHeight = window.innerHeight;
        };

        const checkDebugger = () => {
            const start = performance.now();
            debugger;
            const end = performance.now();
            
            if (end - start > 100) {
                this.showSecurityOverlay('debugger_detected', 'Debugger detectado');
            }
        };

        setInterval(checkWindowSize, 500);
        setInterval(checkDebugger, 1000);
    }

    setupContentProtection() {
        const protectedElements = document.querySelectorAll(`
            h1, h2, h3, h4, h5, h6,
            .card, .hero, .guide-content,
            .code-block, .example, .tutorial
        `);

        protectedElements.forEach(element => {
            element.classList.add('protected-content');
            
            const images = element.querySelectorAll('img');
            images.forEach(img => {
                img.setAttribute('draggable', 'false');
                img.style.pointerEvents = 'none';
            });
        });

        this.addWatermark();
    }

    setupResourceProtection() {
        if (window.self !== window.top) {
            this.showSecurityOverlay('iframe_detected', 'Acesso via iframe não permitido');
        }

        window.addEventListener('beforeprint', (e) => {
            e.preventDefault();
            this.showSecurityToast('Impressão não autorizada', 'warning');
        });
    }

    addWatermark() {
        const watermark = document.createElement('div');
        watermark.className = 'security-watermark';
        watermark.setAttribute('data-security', 'watermark');
        document.body.appendChild(watermark);
    }

    showSecurityOverlay(type, message) {
        if (document.querySelector('.security-overlay')) return;

        const messages = {
            context_menu: {
                icon: 'block',
                title: 'Navegação Protegida',
                message: 'O menu de contexto está desativado nesta página.',
                details: 'Esta ação ajuda a proteger o conteúdo contra cópia não autorizada.'
            },
            dev_tools: {
                icon: 'warning',
                title: 'Acesso Restrito',
                message: 'Ferramentas de desenvolvimento detectadas.',
                details: 'O uso de DevTools está restrito nesta aplicação.'
            },
            dev_tools_detected: {
                icon: 'shield',
                title: 'Proteção Ativada',
                message: 'Atividade suspeita detectada.',
                details: 'Medidas de segurança foram ativadas para proteger o conteúdo.'
            },
            debugger_detected: {
                icon: 'lock',
                title: 'Debugger Bloqueado',
                message: 'Debugging não é permitido.',
                details: 'Esta funcionalidade está desativada por questões de segurança.'
            },
            iframe_detected: {
                icon: 'block',
                title: 'Acesso Bloqueado',
                message: 'Embedding não autorizado.',
                details: 'Este conteúdo não pode ser exibido em iframes.'
            }
        };

        const config = messages[type] || {
            icon: 'shield',
            title: 'Proteção Ativada',
            message: message || 'Ação não permitida.',
            details: 'Esta funcionalidade está protegida por medidas de segurança.'
        };

        const overlay = document.createElement('div');
        overlay.className = 'security-overlay';
        overlay.innerHTML = `
            <div class="security-modal">
                <div class="security-icon">${this.getSecuritySVG(config.icon)}</div>
                <h2 class="security-title">${config.title}</h2>
                <p class="security-message">${config.message}</p>
                <div class="security-details">
                    ${config.details}
                </div>
                <div class="security-timer" id="securityTimer">3</div>
                <div class="security-footer">
                    Guias de Programação • Sistema de Proteção
                </div>
            </div>
        `;

        document.body.appendChild(overlay);
        document.body.style.overflow = 'hidden';

        let countdown = 3;
        const timerElement = overlay.querySelector('#securityTimer');
        const countdownInterval = setInterval(() => {
            countdown--;
            timerElement.textContent = countdown;
            
            if (countdown <= 0) {
                clearInterval(countdownInterval);
                this.removeOverlay(overlay);
            }
        }, 1000);

        setTimeout(() => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    this.removeOverlay(overlay);
                }
            });
        }, 1000);
    }

    showSecurityToast(message, type = 'error') {
        const toast = document.createElement('div');
        toast.className = `security-toast ${type}`;
        
        const iconType = type === 'warning' ? 'warning' : 
                        type === 'info' ? 'info' : 
                        type === 'success' ? 'success' : 'block';
        
        toast.innerHTML = `
            <div class="toast-icon">${this.getSecuritySVG(iconType)}</div>
            <span>${message}</span>
        `;

        document.body.appendChild(toast);

        setTimeout(() => {
            if (toast.parentNode) {
                toast.style.animation = 'slideInRight 0.3s ease reverse';
                setTimeout(() => toast.remove(), 300);
            }
        }, 3000);
    }

    showSecurityStatus() {
        this.showSecurityToast('Sistema de segurança ativo', 'success');
        
        // Mostrar status detalhado no console
        console.log('🛡️ Status do Sistema de Segurança:', {
            level: this.securityLevel,
            protections: {
                contextMenu: '✅ Ativo',
                textSelection: '✅ Restrito',
                devTools: '✅ Monitorado',
                copying: '✅ Restrito',
                resources: '✅ Protegido',
                watermark: '✅ Ativo'
            },
            version: '2.1.0',
            timestamp: new Date().toISOString()
        });
    }

    removeOverlay(overlay) {
        overlay.style.animation = 'securityFadeIn 0.3s ease reverse';
        setTimeout(() => {
            if (overlay.parentNode) {
                overlay.parentNode.removeChild(overlay);
            }
            document.body.style.overflow = '';
        }, 300);
    }

    isAllowedCopy(element) {
        const allowedElements = ['INPUT', 'TEXTAREA', '[contenteditable="true"]'];
        return allowedElements.some(selector => 
            element.matches?.(selector) || element.closest?.(selector)
        );
    }

    encryptData(data) {
        return btoa(unescape(encodeURIComponent(data + this.encryptionKey)))
            .split('').reverse().join('');
    }

    decryptData(encryptedData) {
        try {
            const decoded = atob(encryptedData.split('').reverse().join(''));
            return decodeURIComponent(escape(decoded)).replace(this.encryptionKey, '');
        } catch {
            return encryptedData;
        }
    }

    getSecurityStatus() {
        return {
            level: this.securityLevel,
            protections: {
                contextMenu: 'active',
                textSelection: 'restricted',
                devTools: 'monitored',
                copying: 'restricted',
                resources: 'protected',
                watermark: 'active'
            },
            version: '2.1.0',
            features: ['SVG Icons', 'Floating Shield', 'Modern Design', 'Watermark']
        };
    }
}

console.log('🛡️ Carregando Sistema de Segurança...');

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.securitySystem = new SecuritySystem();
        console.log('✅ Sistema de Segurança inicializado com SVGs');
    });
} else {
    window.securitySystem = new SecuritySystem();
    console.log('✅ Sistema de Segurança inicializado com SVGs');
}

(function() {
    'use strict';
    
    ['contextmenu', 'copy', 'cut', 'dragstart'].forEach(event => {
        document.addEventListener(event, e => e.preventDefault());
    });
    
    console.log('🔒 Proteções básicas ativadas');
})();